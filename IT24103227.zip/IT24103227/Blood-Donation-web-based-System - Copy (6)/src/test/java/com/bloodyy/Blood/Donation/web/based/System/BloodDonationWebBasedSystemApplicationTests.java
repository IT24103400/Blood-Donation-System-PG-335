package com.bloodyy.Blood.Donation.web.based.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloodDonationWebBasedSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
