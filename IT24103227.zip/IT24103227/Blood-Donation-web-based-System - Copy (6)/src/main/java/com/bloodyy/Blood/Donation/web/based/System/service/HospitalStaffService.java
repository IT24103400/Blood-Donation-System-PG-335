package com.bloodyy.Blood.Donation.web.based.System.service;

import com.bloodyy.Blood.Donation.web.based.System.dto.BloodRequestDTO;
import com.bloodyy.Blood.Donation.web.based.System.dto.FeedbackDTO;
import com.bloodyy.Blood.Donation.web.based.System.entity.BloodRequest;
import com.bloodyy.Blood.Donation.web.based.System.entity.Feedback;
import com.bloodyy.Blood.Donation.web.based.System.entity.User;
import com.bloodyy.Blood.Donation.web.based.System.observer.BloodRequestSubject;
import com.bloodyy.Blood.Donation.web.based.System.observer.BloodRequestObserver;
import com.bloodyy.Blood.Donation.web.based.System.repository.BloodRequestRepository;
import com.bloodyy.Blood.Donation.web.based.System.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class HospitalStaffService implements BloodRequestSubject {

    // OBSERVER PATTERN FIELDS
    private List<BloodRequestObserver> observers = new ArrayList<>();

    @Autowired
    private BloodRequestRepository bloodRequestRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private FeedbackService feedbackService;

    // OBSERVER PATTERN METHODS
    @Override
    public void registerObserver(BloodRequestObserver observer) {
        observers.add(observer);
        System.out.println("=== OBSERVER REGISTERED: " + observer.getObserverType() + " ===");
    }

    @Override
    public void removeObserver(BloodRequestObserver observer) {
        observers.remove(observer);
        System.out.println("=== OBSERVER REMOVED: " + observer.getObserverType() + " ===");
    }

    @Override
    public void notifyObservers(BloodRequest bloodRequest) {
        System.out.println("=== NOTIFYING " + observers.size() + " OBSERVERS FOR BLOOD REQUEST: " + bloodRequest.getId() + " ===");

        for (BloodRequestObserver observer : observers) {
            try {
                System.out.println("Notifying observer: " + observer.getObserverType());
                observer.update(bloodRequest);
            } catch (Exception e) {
                System.err.println("Error notifying observer " + observer.getObserverType() + ": " + e.getMessage());
                e.printStackTrace();
            }
        }

        System.out.println("=== ALL OBSERVERS NOTIFIED SUCCESSFULLY ===");
    }

    @Override
    public List<String> getRegisteredObservers() {
        List<String> observerTypes = new ArrayList<>();
        for (BloodRequestObserver observer : observers) {
            observerTypes.add(observer.getObserverType());
        }
        return observerTypes;
    }

    // MAIN BLOOD REQUEST METHOD (NOW WITH OBSERVER NOTIFICATION)
    public BloodRequest createBloodRequest(BloodRequestDTO requestDTO, User hospitalStaff) {
        // Validate required fields
        if (requestDTO.getBloodType() == null || requestDTO.getBloodType().isEmpty()) {
            throw new IllegalArgumentException("Blood type is required");
        }
        if (requestDTO.getQuantity() == null || requestDTO.getQuantity() <= 0) {
            throw new IllegalArgumentException("Valid quantity is required");
        }
        if (requestDTO.getPatientDetails() == null || requestDTO.getPatientDetails().isEmpty()) {
            throw new IllegalArgumentException("Patient details are required");
        }
        if (requestDTO.getHospitalName() == null || requestDTO.getHospitalName().isEmpty()) {
            throw new IllegalArgumentException("Hospital name is required");
        }

        System.out.println("=== CREATING BLOOD REQUEST ===");
        System.out.println("Blood Type: " + requestDTO.getBloodType());
        System.out.println("Quantity: " + requestDTO.getQuantity());
        System.out.println("Urgency: " + requestDTO.getUrgency());
        System.out.println("Hospital: " + requestDTO.getHospitalName());

        BloodRequest bloodRequest = new BloodRequest();
        bloodRequest.setHospitalStaff(hospitalStaff);
        bloodRequest.setBloodType(requestDTO.getBloodType());
        bloodRequest.setQuantity(requestDTO.getQuantity());
        bloodRequest.setUrgency(requestDTO.getUrgency() != null ? requestDTO.getUrgency() : "MEDIUM");
        bloodRequest.setPatientDetails(requestDTO.getPatientDetails());
        bloodRequest.setNotes(requestDTO.getNotes());
        bloodRequest.setHospitalName(requestDTO.getHospitalName());
        bloodRequest.setHospitalAddress(requestDTO.getHospitalAddress());
        bloodRequest.setContactPerson(requestDTO.getContactPerson());
        bloodRequest.setContactPhone(requestDTO.getContactPhone());
        bloodRequest.setStatus("PENDING");
        bloodRequest.setRequestDate(LocalDateTime.now());

        BloodRequest savedRequest = bloodRequestRepository.save(bloodRequest);
        System.out.println("=== BLOOD REQUEST SAVED WITH ID: " + savedRequest.getId() + " ===");

        // NOTIFY ALL REGISTERED OBSERVERS
        notifyObservers(savedRequest);

        // Also notify medical staff via email (existing functionality)
        notifyMedicalStaff(savedRequest);

        System.out.println("=== BLOOD REQUEST PROCESSING COMPLETED ===");
        return savedRequest;
    }

    private void notifyMedicalStaff(BloodRequest bloodRequest) {
        try {
            // Get all medical staff to notify
            List<User> medicalStaff = userRepository.findByUser_type("MEDICAL_STAFF");

            System.out.println("=== SENDING EMAIL NOTIFICATIONS TO " + medicalStaff.size() + " MEDICAL STAFF ===");

            for (User staff : medicalStaff) {
                emailService.sendBloodRequestNotification(
                        staff.getEmail(),
                        staff.getFirstName(),
                        bloodRequest.getId(),
                        bloodRequest.getBloodType(),
                        bloodRequest.getQuantity(),
                        bloodRequest.getUrgency(),
                        bloodRequest.getHospitalName()
                );
            }

            System.out.println("=== EMAIL NOTIFICATIONS SENT SUCCESSFULLY ===");

        } catch (Exception e) {
            System.err.println("Failed to send notification to medical staff: " + e.getMessage());
            // Don't throw exception - email failure shouldn't prevent request creation
        }
    }

    public List<BloodRequest> getBloodRequestsByHospitalStaff(Long hospitalStaffId) {
        return bloodRequestRepository.findByHospitalStaffIdOrderByRequestDateDesc(hospitalStaffId);
    }

    public List<BloodRequest> getPendingBloodRequests() {
        return bloodRequestRepository.findByStatusOrderByRequestDateDesc("PENDING");
    }

    public long getPendingRequestsCount() {
        return bloodRequestRepository.countByStatus("PENDING");
    }

    public long getPendingRequestsCountByHospital(Long hospitalStaffId) {
        return bloodRequestRepository.countByHospitalStaffIdAndStatus(hospitalStaffId, "PENDING");
    }

    public BloodRequest getBloodRequestById(Long requestId) {
        return bloodRequestRepository.findById(requestId).orElse(null);
    }

    public List<BloodRequest> getBloodRequestHistory(Long hospitalStaffId) {
        return bloodRequestRepository.findByHospitalStaffIdOrderByRequestDateDesc(hospitalStaffId);
    }

    // Method to get request details for viewing
    public BloodRequest getRequestDetails(Long requestId, Long hospitalStaffId) {
        // Use the repository method that returns Optional and handle it properly
        Optional<BloodRequest> requestOpt = bloodRequestRepository.findByIdAndHospitalStaffId(requestId, hospitalStaffId);
        return requestOpt.orElse(null); // Return the BloodRequest or null if not found
    }

    // Method to update blood request
    public BloodRequest updateBloodRequest(Long requestId, BloodRequestDTO requestDTO, User hospitalStaff) {
        // Get the Optional from repository
        Optional<BloodRequest> requestOpt = bloodRequestRepository.findByIdAndHospitalStaffId(requestId, hospitalStaff.getId());

        if (requestOpt.isPresent()) {
            BloodRequest request = requestOpt.get();

            // Only allow updates for pending requests
            if (!"PENDING".equals(request.getStatus())) {
                throw new IllegalStateException("Cannot update request with status: " + request.getStatus());
            }

            System.out.println("=== UPDATING BLOOD REQUEST: " + requestId + " ===");

            // Update fields
            request.setBloodType(requestDTO.getBloodType());
            request.setQuantity(requestDTO.getQuantity());
            request.setUrgency(requestDTO.getUrgency());
            request.setPatientDetails(requestDTO.getPatientDetails());
            request.setNotes(requestDTO.getNotes());
            request.setHospitalName(requestDTO.getHospitalName());
            request.setHospitalAddress(requestDTO.getHospitalAddress());
            request.setContactPerson(requestDTO.getContactPerson());
            request.setContactPhone(requestDTO.getContactPhone());

            BloodRequest updatedRequest = bloodRequestRepository.save(request);

            System.out.println("=== BLOOD REQUEST UPDATED SUCCESSFULLY ===");

            return updatedRequest;
        }

        throw new IllegalArgumentException("Request not found or access denied");
    }

    // Method to cancel blood request
    public boolean cancelBloodRequest(Long requestId, String reason, User hospitalStaff) {
        // First check if the request exists and belongs to this hospital staff
        Optional<BloodRequest> requestOpt = bloodRequestRepository.findByIdAndHospitalStaffId(requestId, hospitalStaff.getId());

        if (requestOpt.isPresent()) {
            BloodRequest request = requestOpt.get();

            // Only allow cancellation of pending requests
            if (!"PENDING".equals(request.getStatus())) {
                throw new IllegalStateException("Cannot cancel request with status: " + request.getStatus());
            }

            System.out.println("=== CANCELLING BLOOD REQUEST: " + requestId + " ===");
            System.out.println("Cancellation Reason: " + reason);

            // Update the request status and cancellation details
            request.setStatus("CANCELLED");
            request.setCancellationReason(reason);
            request.setCancellationDate(LocalDateTime.now());

            bloodRequestRepository.save(request);

            System.out.println("=== BLOOD REQUEST CANCELLED SUCCESSFULLY ===");

            return true;
        }

        return false;
    }

    // Feedback methods for hospital staff
    public Feedback createFeedback(FeedbackDTO feedbackDTO, User hospitalStaff) {
        return feedbackService.createHospitalStaffFeedback(feedbackDTO, hospitalStaff);
    }

    public List<Feedback> getHospitalStaffFeedbacks(Long hospitalStaffId) {
        return feedbackService.getHospitalStaffFeedbacks(hospitalStaffId);
    }

    public List<Feedback> getHospitalStaffPendingFeedbacks(Long hospitalStaffId) {
        return feedbackService.getHospitalStaffPendingFeedbacks(hospitalStaffId);
    }

    public Feedback updateFeedback(Long feedbackId, FeedbackDTO feedbackDTO, User hospitalStaff) {
        return feedbackService.updateFeedback(feedbackId, feedbackDTO, hospitalStaff);
    }

    public boolean deleteFeedback(Long feedbackId, User hospitalStaff) {
        return feedbackService.deleteFeedback(feedbackId, hospitalStaff);
    }

    // NEW METHOD: Get observer status for debugging
    public String getObserverStatus() {
        List<String> observerTypes = getRegisteredObservers();
        if (observerTypes.isEmpty()) {
            return "No observers registered";
        } else {
            return "Registered observers: " + String.join(", ", observerTypes) +
                    " (Total: " + observerTypes.size() + ")";
        }
    }

    // NEW METHOD: Create emergency blood request (if you want separate emergency handling)
    public BloodRequest createEmergencyBloodRequest(BloodRequestDTO requestDTO, User hospitalStaff) {
        // Force urgency to EMERGENCY
        requestDTO.setUrgency("EMERGENCY");

        System.out.println("=== CREATING EMERGENCY BLOOD REQUEST ===");
        System.out.println("EMERGENCY - Blood Type: " + requestDTO.getBloodType());
        System.out.println("EMERGENCY - Quantity: " + requestDTO.getQuantity());

        return createBloodRequest(requestDTO, hospitalStaff);
    }
}