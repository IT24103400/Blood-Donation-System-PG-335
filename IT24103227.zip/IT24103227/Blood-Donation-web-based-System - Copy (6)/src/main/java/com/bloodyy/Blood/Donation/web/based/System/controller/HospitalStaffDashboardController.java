package com.bloodyy.Blood.Donation.web.based.System.controller;

import com.bloodyy.Blood.Donation.web.based.System.dto.BloodRequestDTO;
import com.bloodyy.Blood.Donation.web.based.System.dto.FeedbackDTO;
import com.bloodyy.Blood.Donation.web.based.System.dto.PasswordChangeDTO;
import com.bloodyy.Blood.Donation.web.based.System.entity.BloodRequest;
import com.bloodyy.Blood.Donation.web.based.System.entity.Feedback;
import com.bloodyy.Blood.Donation.web.based.System.entity.User;
import com.bloodyy.Blood.Donation.web.based.System.service.FeedbackService;
import com.bloodyy.Blood.Donation.web.based.System.service.HospitalStaffService;
import com.bloodyy.Blood.Donation.web.based.System.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;

@Controller
@RequestMapping("/hospital-staff")
public class HospitalStaffDashboardController {

    @Autowired
    private UserService userService;

    @Autowired
    private HospitalStaffService hospitalStaffService;

    @Autowired
    private FeedbackService feedbackService;

    @GetMapping("/dashboard")
    public String hospitalStaffDashboard(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login?error=access_denied";
        }

        model.addAttribute("user", user);
        model.addAttribute("bloodRequestDTO", new BloodRequestDTO());

        // Check if user needs to change password
        if (user.getIsTempPassword()) {
            model.addAttribute("passwordChangeDTO", new PasswordChangeDTO());
            model.addAttribute("requirePasswordChange", true);
        } else {
            model.addAttribute("requirePasswordChange", false);

            // Get blood requests for this hospital staff
            List<BloodRequest> bloodRequests = hospitalStaffService.getBloodRequestsByHospitalStaff(user.getId());
            long pendingRequests = hospitalStaffService.getPendingRequestsCountByHospital(user.getId());
            long approvedCount = getApprovedRequestsCount(bloodRequests);

            model.addAttribute("bloodRequests", bloodRequests);
            model.addAttribute("pendingRequests", pendingRequests);
            model.addAttribute("approvedCount", approvedCount);

            // Add feedback functionality
            model.addAttribute("feedbackDTO", new FeedbackDTO());
            model.addAttribute("userFeedbacks", feedbackService.getUserFeedbacks(user.getId()));
        }

        return "hospital-staff-dashboard";
    }

    private long getApprovedRequestsCount(List<BloodRequest> requests) {
        if (requests == null) return 0;
        return requests.stream()
                .filter(r -> "APPROVED".equals(r.getStatus()))
                .count();
    }

    @PostMapping("/request-blood")
    public String requestBlood(@ModelAttribute BloodRequestDTO bloodRequestDTO,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        // Check if user needs to change password first
        if (user.getIsTempPassword()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please change your password first before making requests.");
            return "redirect:/hospital-staff/dashboard";
        }

        try {
            BloodRequest bloodRequest = hospitalStaffService.createBloodRequest(bloodRequestDTO, user);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Blood request submitted successfully! Request ID: " + bloodRequest.getId() +
                            ". Medical staff have been notified.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Failed to submit blood request: " + e.getMessage());
        }

        return "redirect:/hospital-staff/dashboard";
    }

    @PostMapping("/change-password")
    public String changePassword(@ModelAttribute PasswordChangeDTO passwordChangeDTO,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            boolean success = userService.changePassword(user.getId(), passwordChangeDTO);
            if (success) {
                // Update session user with new password status
                User updatedUser = userService.getUserById(user.getId());
                session.setAttribute("user", updatedUser);
                redirectAttributes.addFlashAttribute("successMessage", "Password changed successfully!");
                return "redirect:/hospital-staff/dashboard";
            } else {
                redirectAttributes.addFlashAttribute("errorMessage",
                        "Failed to change password. Please check your current password.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Error changing password: " + e.getMessage());
        }

        return "redirect:/hospital-staff/dashboard";
    }

    @GetMapping("/request-history")
    public String requestHistory(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        List<BloodRequest> bloodRequests = hospitalStaffService.getBloodRequestHistory(user.getId());
        model.addAttribute("bloodRequests", bloodRequests);
        model.addAttribute("user", user);

        return "hospital-request-history";
    }

    @GetMapping("/request-details/{requestId}")
    public String requestDetails(@PathVariable Long requestId, Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        BloodRequest bloodRequest = hospitalStaffService.getRequestDetails(requestId, user.getId());
        if (bloodRequest == null) {
            return "redirect:/hospital-staff/dashboard?error=request_not_found";
        }

        model.addAttribute("bloodRequest", bloodRequest);
        model.addAttribute("user", user);

        return "hospital-request-details";
    }

    @GetMapping("/edit-request/{requestId}")
    public String showEditRequestForm(@PathVariable Long requestId, Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        BloodRequest bloodRequest = hospitalStaffService.getRequestDetails(requestId, user.getId());
        if (bloodRequest == null) {
            return "redirect:/hospital-staff/dashboard?error=request_not_found";
        }

        // Only allow editing of pending requests
        if (!"PENDING".equals(bloodRequest.getStatus())) {
            return "redirect:/hospital-staff/request-details/" + requestId + "?error=cannot_edit";
        }

        BloodRequestDTO bloodRequestDTO = new BloodRequestDTO();
        bloodRequestDTO.setRequestId(bloodRequest.getId());
        bloodRequestDTO.setBloodType(bloodRequest.getBloodType());
        bloodRequestDTO.setQuantity(bloodRequest.getQuantity());
        bloodRequestDTO.setUrgency(bloodRequest.getUrgency());
        bloodRequestDTO.setPatientDetails(bloodRequest.getPatientDetails());
        bloodRequestDTO.setNotes(bloodRequest.getNotes());
        bloodRequestDTO.setHospitalName(bloodRequest.getHospitalName());
        bloodRequestDTO.setHospitalAddress(bloodRequest.getHospitalAddress());
        bloodRequestDTO.setContactPerson(bloodRequest.getContactPerson());
        bloodRequestDTO.setContactPhone(bloodRequest.getContactPhone());

        model.addAttribute("bloodRequestDTO", bloodRequestDTO);
        model.addAttribute("user", user);

        return "hospital-edit-request";
    }

    @PostMapping("/edit-request/{requestId}")
    public String updateRequest(@PathVariable Long requestId,
                                @ModelAttribute BloodRequestDTO bloodRequestDTO,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            BloodRequest updatedRequest = hospitalStaffService.updateBloodRequest(requestId, bloodRequestDTO, user);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Blood request #" + requestId + " updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Failed to update blood request: " + e.getMessage());
        }

        return "redirect:/hospital-staff/request-details/" + requestId;
    }

    @PostMapping("/cancel-request/{requestId}")
    public String cancelRequest(@PathVariable Long requestId,
                                @RequestParam String cancellationReason,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            boolean cancelled = hospitalStaffService.cancelBloodRequest(requestId, cancellationReason, user);
            if (cancelled) {
                redirectAttributes.addFlashAttribute("successMessage",
                        "Blood request #" + requestId + " cancelled successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage",
                        "Failed to cancel blood request. It may have already been processed.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Failed to cancel blood request: " + e.getMessage());
        }

        return "redirect:/hospital-staff/request-details/" + requestId;
    }

    // New endpoint to show request form
    @GetMapping("/new-request")
    public String showNewRequestForm(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        if (user.getIsTempPassword()) {
            return "redirect:/hospital-staff/dashboard?error=change_password_first";
        }

        model.addAttribute("bloodRequestDTO", new BloodRequestDTO());
        model.addAttribute("user", user);

        return "hospital-new-request";
    }

    // Hospital Staff Feedback Management
    @GetMapping("/feedback")
    public String hospitalStaffFeedback(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        List<Feedback> feedbacks = hospitalStaffService.getHospitalStaffFeedbacks(user.getId());
        model.addAttribute("feedbacks", feedbacks);
        model.addAttribute("feedbackDTO", new FeedbackDTO());
        model.addAttribute("user", user);

        return "hospital-staff-feedback";
    }

    @PostMapping("/feedback/submit")
    public String submitFeedback(@ModelAttribute FeedbackDTO feedbackDTO,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            Feedback feedback = hospitalStaffService.createFeedback(feedbackDTO, user);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Feedback submitted successfully! It will be reviewed by our team.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/hospital-staff/feedback";
    }

    @GetMapping("/feedback/edit/{feedbackId}")
    public String showEditFeedbackForm(@PathVariable Long feedbackId,
                                       Model model,
                                       HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        Feedback feedback = feedbackService.getFeedbackByIdAndUserId(feedbackId, user.getId());
        if (feedback == null) {
            return "redirect:/hospital-staff/feedback?error=not_found";
        }

        // Only allow editing if status is PENDING
        if (!"PENDING".equals(feedback.getStatus())) {
            return "redirect:/hospital-staff/feedback?error=cannot_edit";
        }

        FeedbackDTO feedbackDTO = new FeedbackDTO();
        feedbackDTO.setContent(feedback.getContent());
        feedbackDTO.setFeedbackId(feedback.getId());

        model.addAttribute("feedback", feedback);
        model.addAttribute("feedbackDTO", feedbackDTO);
        model.addAttribute("user", user);

        return "hospital-staff-edit-feedback";
    }

    @PostMapping("/feedback/edit/{feedbackId}")
    public String editFeedback(@PathVariable Long feedbackId,
                               @ModelAttribute FeedbackDTO feedbackDTO,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            Feedback updatedFeedback = hospitalStaffService.updateFeedback(feedbackId, feedbackDTO, user);
            redirectAttributes.addFlashAttribute("successMessage", "Feedback updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/hospital-staff/feedback";
    }

    @PostMapping("/feedback/delete/{feedbackId}")
    public String deleteFeedback(@PathVariable Long feedbackId,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"HOSPITAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            boolean deleted = hospitalStaffService.deleteFeedback(feedbackId, user);
            if (deleted) {
                redirectAttributes.addFlashAttribute("successMessage", "Feedback deleted successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to delete feedback.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/hospital-staff/feedback";
    }
}