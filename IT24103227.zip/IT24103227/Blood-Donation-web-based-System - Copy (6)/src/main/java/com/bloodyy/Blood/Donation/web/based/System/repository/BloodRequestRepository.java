package com.bloodyy.Blood.Donation.web.based.System.repository;

import com.bloodyy.Blood.Donation.web.based.System.entity.BloodRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {

    // ===== EXISTING METHODS =====

    // Find requests by hospital staff ID
    @Query("SELECT br FROM BloodRequest br WHERE br.hospitalStaff.id = :hospitalStaffId ORDER BY br.requestDate DESC")
    List<BloodRequest> findByHospitalStaffIdOrderByRequestDateDesc(@Param("hospitalStaffId") Long hospitalStaffId);

    // Find requests by medical staff ID
    @Query("SELECT br FROM BloodRequest br WHERE br.medicalStaff.id = :medicalStaffId ORDER BY br.requestDate DESC")
    List<BloodRequest> findByMedicalStaffIdOrderByRequestDateDesc(@Param("medicalStaffId") Long medicalStaffId);

    // Find requests by status
    @Query("SELECT br FROM BloodRequest br WHERE br.status = :status ORDER BY br.requestDate DESC")
    List<BloodRequest> findByStatusOrderByRequestDateDesc(@Param("status") String status);

    // Find requests by urgency
    @Query("SELECT br FROM BloodRequest br WHERE br.urgency = :urgency ORDER BY br.requestDate DESC")
    List<BloodRequest> findByUrgencyOrderByRequestDateDesc(@Param("urgency") String urgency);

    // Find all requests ordered by date
    @Query("SELECT br FROM BloodRequest br ORDER BY br.requestDate DESC")
    List<BloodRequest> findAllByOrderByRequestDateDesc();

    // Find pending requests ordered by urgency (critical first)
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'PENDING' ORDER BY " +
            "CASE br.urgency " +
            "WHEN 'CRITICAL' THEN 1 " +
            "WHEN 'HIGH' THEN 2 " +
            "WHEN 'MEDIUM' THEN 3 " +
            "WHEN 'LOW' THEN 4 " +
            "END, br.requestDate ASC")
    List<BloodRequest> findPendingRequestsOrderedByUrgency();

    // Count requests by status
    long countByStatus(String status);

    // Count requests by hospital staff ID and status
    @Query("SELECT COUNT(br) FROM BloodRequest br WHERE br.hospitalStaff.id = :hospitalStaffId AND br.status = :status")
    long countByHospitalStaffIdAndStatus(@Param("hospitalStaffId") Long hospitalStaffId, @Param("status") String status);

    // Find request by ID and hospital staff ID (for authorization) - returns Optional
    @Query("SELECT br FROM BloodRequest br WHERE br.id = :id AND br.hospitalStaff.id = :hospitalStaffId")
    Optional<BloodRequest> findByIdAndHospitalStaffId(@Param("id") Long id, @Param("hospitalStaffId") Long hospitalStaffId);

    // Find request by ID and medical staff ID (for authorization) - returns Optional
    @Query("SELECT br FROM BloodRequest br WHERE br.id = :id AND br.medicalStaff.id = :medicalStaffId")
    Optional<BloodRequest> findByIdAndMedicalStaffId(@Param("id") Long id, @Param("medicalStaffId") Long medicalStaffId);

    // Find requests by hospital name (for reporting)
    @Query("SELECT br FROM BloodRequest br WHERE br.hospitalName LIKE %:hospitalName% ORDER BY br.requestDate DESC")
    List<BloodRequest> findByHospitalNameContainingOrderByRequestDateDesc(@Param("hospitalName") String hospitalName);

    // Find requests by blood type
    @Query("SELECT br FROM BloodRequest br WHERE br.bloodType = :bloodType ORDER BY br.requestDate DESC")
    List<BloodRequest> findByBloodTypeOrderByRequestDateDesc(@Param("bloodType") String bloodType);

    // Find requests within date range
    @Query("SELECT br FROM BloodRequest br WHERE br.requestDate BETWEEN :startDate AND :endDate ORDER BY br.requestDate DESC")
    List<BloodRequest> findByRequestDateBetweenOrderByRequestDateDesc(@Param("startDate") LocalDateTime startDate,
                                                                      @Param("endDate") LocalDateTime endDate);

    // Find requests with quantity greater than specified
    @Query("SELECT br FROM BloodRequest br WHERE br.quantity >= :minQuantity ORDER BY br.requestDate DESC")
    List<BloodRequest> findByQuantityGreaterThanEqualOrderByRequestDateDesc(@Param("minQuantity") Integer minQuantity);

    // Cancel request with reason (custom update query)
    @Transactional
    @Modifying
    @Query("UPDATE BloodRequest br SET br.status = 'CANCELLED', br.cancellationDate = CURRENT_TIMESTAMP, br.cancellationReason = :reason WHERE br.id = :id AND br.hospitalStaff.id = :hospitalStaffId")
    int cancelRequest(@Param("id") Long id, @Param("hospitalStaffId") Long hospitalStaffId, @Param("reason") String reason);

    // Find requests by hospital staff ID and status
    @Query("SELECT br FROM BloodRequest br WHERE br.hospitalStaff.id = :hospitalStaffId AND br.status = :status ORDER BY br.requestDate DESC")
    List<BloodRequest> findByHospitalStaffIdAndStatusOrderByRequestDateDesc(@Param("hospitalStaffId") Long hospitalStaffId, @Param("status") String status);

    // Find requests by medical staff ID and status
    @Query("SELECT br FROM BloodRequest br WHERE br.medicalStaff.id = :medicalStaffId AND br.status = :status ORDER BY br.requestDate DESC")
    List<BloodRequest> findByMedicalStaffIdAndStatusOrderByRequestDateDesc(@Param("medicalStaffId") Long medicalStaffId, @Param("status") String status);

    // Find requests that need urgent attention (CRITICAL or HIGH urgency)
    @Query("SELECT br FROM BloodRequest br WHERE br.urgency IN ('CRITICAL', 'HIGH') AND br.status = 'PENDING' ORDER BY br.requestDate DESC")
    List<BloodRequest> findUrgentPendingRequests();

    // Count pending requests by hospital
    @Query("SELECT COUNT(br) FROM BloodRequest br WHERE br.hospitalName = :hospitalName AND br.status = 'PENDING'")
    long countPendingRequestsByHospital(@Param("hospitalName") String hospitalName);

    // Find recent requests (last 7 days)
    @Query("SELECT br FROM BloodRequest br WHERE br.requestDate >= :startDate ORDER BY br.requestDate DESC")
    List<BloodRequest> findRecentRequests(@Param("startDate") LocalDateTime startDate);

    // Find requests by contact phone
    @Query("SELECT br FROM BloodRequest br WHERE br.contactPhone LIKE %:phone% ORDER BY br.requestDate DESC")
    List<BloodRequest> findByContactPhoneContainingOrderByRequestDateDesc(@Param("phone") String phone);

    // Find requests by contact person
    @Query("SELECT br FROM BloodRequest br WHERE br.contactPerson LIKE %:person% ORDER BY br.requestDate DESC")
    List<BloodRequest> findByContactPersonContainingOrderByRequestDateDesc(@Param("person") String person);

    // ===== NEW FIFO-RELATED METHODS =====

    // Find approved requests ordered by urgency and response date for FIFO fulfillment
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'APPROVED' ORDER BY " +
            "CASE br.urgency " +
            "WHEN 'CRITICAL' THEN 1 " +
            "WHEN 'HIGH' THEN 2 " +
            "WHEN 'MEDIUM' THEN 3 " +
            "WHEN 'LOW' THEN 4 " +
            "END, br.responseDate ASC")
    List<BloodRequest> findApprovedRequestsOrderedByUrgency();

    // Find requests processed by medical staff (approved, rejected, fulfilled)
    @Query("SELECT br FROM BloodRequest br WHERE br.status IN ('APPROVED', 'REJECTED', 'FULFILLED') AND br.medicalStaff.id = :medicalStaffId ORDER BY br.responseDate DESC")
    List<BloodRequest> findProcessedRequestsByMedicalStaff(@Param("medicalStaffId") Long medicalStaffId);

    // Find fulfilled requests for tracking
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'FULFILLED' ORDER BY br.responseDate DESC")
    List<BloodRequest> findFulfilledRequestsOrderByResponseDateDesc();

    // Find approved requests by blood type (for inventory planning)
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'APPROVED' AND br.bloodType = :bloodType ORDER BY " +
            "CASE br.urgency " +
            "WHEN 'CRITICAL' THEN 1 " +
            "WHEN 'HIGH' THEN 2 " +
            "WHEN 'MEDIUM' THEN 3 " +
            "WHEN 'LOW' THEN 4 " +
            "END, br.responseDate ASC")
    List<BloodRequest> findApprovedRequestsByBloodTypeOrderedByUrgency(@Param("bloodType") String bloodType);

    // Count approved requests waiting for fulfillment
    @Query("SELECT COUNT(br) FROM BloodRequest br WHERE br.status = 'APPROVED'")
    long countApprovedRequests();

    // Count fulfilled requests by medical staff
    @Query("SELECT COUNT(br) FROM BloodRequest br WHERE br.status = 'FULFILLED' AND br.medicalStaff.id = :medicalStaffId")
    long countFulfilledRequestsByMedicalStaff(@Param("medicalStaffId") Long medicalStaffId);

    // Find requests by multiple statuses (for dashboard overview)
    @Query("SELECT br FROM BloodRequest br WHERE br.status IN :statuses ORDER BY br.requestDate DESC")
    List<BloodRequest> findByStatusInOrderByRequestDateDesc(@Param("statuses") List<String> statuses);

    // Find requests that can be fulfilled with available inventory
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'APPROVED' AND br.bloodType = :bloodType AND br.quantity <= :availableQuantity ORDER BY " +
            "CASE br.urgency " +
            "WHEN 'CRITICAL' THEN 1 " +
            "WHEN 'HIGH' THEN 2 " +
            "WHEN 'MEDIUM' THEN 3 " +
            "WHEN 'LOW' THEN 4 " +
            "END, br.responseDate ASC")
    List<BloodRequest> findFulfillableRequests(@Param("bloodType") String bloodType, @Param("availableQuantity") Integer availableQuantity);

    // Get statistics for dashboard
    @Query("SELECT br.status, COUNT(br) FROM BloodRequest br GROUP BY br.status")
    List<Object[]> getRequestStatistics();

    // Get statistics by blood type
    @Query("SELECT br.bloodType, br.status, COUNT(br) FROM BloodRequest br GROUP BY br.bloodType, br.status")
    List<Object[]> getRequestStatisticsByBloodType();

    // Get statistics by urgency
    @Query("SELECT br.urgency, br.status, COUNT(br) FROM BloodRequest br GROUP BY br.urgency, br.status")
    List<Object[]> getRequestStatisticsByUrgency();

    // Find requests pending for more than specified hours
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'PENDING' AND br.requestDate < :thresholdDate ORDER BY br.requestDate ASC")
    List<BloodRequest> findOverdueRequests(@Param("thresholdDate") LocalDateTime thresholdDate);

    // Find requests approved but not fulfilled within specified hours
    @Query("SELECT br FROM BloodRequest br WHERE br.status = 'APPROVED' AND br.responseDate < :thresholdDate ORDER BY br.responseDate ASC")
    List<BloodRequest> findOverdueApprovedRequests(@Param("thresholdDate") LocalDateTime thresholdDate);

    // Update request status to fulfilled with fulfillment details
    @Transactional
    @Modifying
    @Query("UPDATE BloodRequest br SET br.status = 'FULFILLED', br.fulfillmentDate = :fulfillmentDate, br.notes = CONCAT(COALESCE(br.notes, ''), :notes) WHERE br.id = :id")
    int fulfillRequest(@Param("id") Long id, @Param("fulfillmentDate") LocalDateTime fulfillmentDate, @Param("notes") String notes);

    // Find requests by hospital staff with pagination support
    @Query("SELECT br FROM BloodRequest br WHERE br.hospitalStaff.id = :hospitalStaffId ORDER BY br.requestDate DESC")
    List<BloodRequest> findByHospitalStaffIdWithPagination(@Param("hospitalStaffId") Long hospitalStaffId);

    // Find requests by blood type and status with urgency ordering
    @Query("SELECT br FROM BloodRequest br WHERE br.bloodType = :bloodType AND br.status = :status ORDER BY " +
            "CASE br.urgency " +
            "WHEN 'CRITICAL' THEN 1 " +
            "WHEN 'HIGH' THEN 2 " +
            "WHEN 'MEDIUM' THEN 3 " +
            "WHEN 'LOW' THEN 4 " +
            "END, br.requestDate ASC")
    List<BloodRequest> findByBloodTypeAndStatusOrderedByUrgency(@Param("bloodType") String bloodType, @Param("status") String status);

    // Get total quantity requested by blood type for planning
    @Query("SELECT br.bloodType, SUM(br.quantity) FROM BloodRequest br WHERE br.status IN ('PENDING', 'APPROVED') GROUP BY br.bloodType")
    List<Object[]> getTotalQuantityRequestedByBloodType();

    // Find requests that need immediate attention (critical + old pending)
    @Query("SELECT br FROM BloodRequest br WHERE " +
            "(br.urgency = 'CRITICAL' AND br.status = 'PENDING') OR " +
            "(br.status = 'PENDING' AND br.requestDate < :urgentThreshold) OR " +
            "(br.status = 'APPROVED' AND br.responseDate < :overdueThreshold) " +
            "ORDER BY " +
            "CASE " +
            "WHEN br.urgency = 'CRITICAL' AND br.status = 'PENDING' THEN 1 " +
            "WHEN br.status = 'APPROVED' AND br.responseDate < :overdueThreshold THEN 2 " +
            "WHEN br.status = 'PENDING' AND br.requestDate < :urgentThreshold THEN 3 " +
            "END, br.requestDate ASC")
    List<BloodRequest> findRequestsNeedingImmediateAttention(@Param("urgentThreshold") LocalDateTime urgentThreshold,
                                                             @Param("overdueThreshold") LocalDateTime overdueThreshold);

    // Fixed method - using native query for correct time difference calculation
    @Query(value = "SELECT blood_type, AVG(TIMESTAMPDIFF(HOUR, response_date, fulfillment_date)) as avg_time " +
            "FROM blood_requests WHERE status = 'FULFILLED' AND response_date IS NOT NULL AND fulfillment_date IS NOT NULL " +
            "GROUP BY blood_type", nativeQuery = true)
    List<Object[]> getAverageFulfillmentTimeByBloodType();

    // Find requests by medical staff within date range
    @Query("SELECT br FROM BloodRequest br WHERE br.medicalStaff.id = :medicalStaffId " +
            "AND br.responseDate BETWEEN :startDate AND :endDate ORDER BY br.responseDate DESC")
    List<BloodRequest> findByMedicalStaffAndDateRange(@Param("medicalStaffId") Long medicalStaffId,
                                                      @Param("startDate") LocalDateTime startDate,
                                                      @Param("endDate") LocalDateTime endDate);

    // Get monthly request statistics
    @Query("SELECT FUNCTION('YEAR', br.requestDate), FUNCTION('MONTH', br.requestDate), COUNT(br) " +
            "FROM BloodRequest br GROUP BY FUNCTION('YEAR', br.requestDate), FUNCTION('MONTH', br.requestDate) " +
            "ORDER BY FUNCTION('YEAR', br.requestDate) DESC, FUNCTION('MONTH', br.requestDate) DESC")
    List<Object[]> getMonthlyRequestStatistics();

    // Find requests by hospital with status filter
    @Query("SELECT br FROM BloodRequest br WHERE br.hospitalName = :hospitalName AND br.status = :status " +
            "ORDER BY br.requestDate DESC")
    List<BloodRequest> findByHospitalAndStatus(@Param("hospitalName") String hospitalName, @Param("status") String status);

    // Count requests by medical staff and status
    @Query("SELECT COUNT(br) FROM BloodRequest br WHERE br.medicalStaff.id = :medicalStaffId AND br.status = :status")
    long countByMedicalStaffAndStatus(@Param("medicalStaffId") Long medicalStaffId, @Param("status") String status);

    // Find top requesting hospitals
    @Query("SELECT br.hospitalName, COUNT(br) as requestCount FROM BloodRequest br " +
            "WHERE br.requestDate >= :startDate GROUP BY br.hospitalName ORDER BY requestCount DESC")
    List<Object[]> findTopRequestingHospitals(@Param("startDate") LocalDateTime startDate);

    // Find requests with specific blood type and urgency combinations
    @Query("SELECT br FROM BloodRequest br WHERE br.bloodType IN :bloodTypes AND br.urgency IN :urgencies " +
            "AND br.status = :status ORDER BY " +
            "CASE br.urgency " +
            "WHEN 'CRITICAL' THEN 1 " +
            "WHEN 'HIGH' THEN 2 " +
            "WHEN 'MEDIUM' THEN 3 " +
            "WHEN 'LOW' THEN 4 " +
            "END, br.requestDate ASC")
    List<BloodRequest> findByBloodTypesAndUrgenciesAndStatus(@Param("bloodTypes") List<String> bloodTypes,
                                                             @Param("urgencies") List<String> urgencies,
                                                             @Param("status") String status);
}