package com.bloodyy.Blood.Donation.web.based.System.controller;

import com.bloodyy.Blood.Donation.web.based.System.dto.BloodInventoryDTO;
import com.bloodyy.Blood.Donation.web.based.System.dto.PasswordChangeDTO;
import com.bloodyy.Blood.Donation.web.based.System.entity.BloodInventory;
import com.bloodyy.Blood.Donation.web.based.System.entity.BloodRequest;
import com.bloodyy.Blood.Donation.web.based.System.entity.Notification;
import com.bloodyy.Blood.Donation.web.based.System.entity.User;
import com.bloodyy.Blood.Donation.web.based.System.service.MedicalStaffService;
import com.bloodyy.Blood.Donation.web.based.System.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/medical-staff")
public class MedicalStaffDashboardController {

    @Autowired
    private UserService userService;

    @Autowired
    private MedicalStaffService medicalStaffService;

    @GetMapping("/dashboard")
    public String medicalStaffDashboard(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login?error=access_denied";
        }

        model.addAttribute("user", user);
        model.addAttribute("bloodInventoryDTO", new BloodInventoryDTO());

        if (user.getIsTempPassword()) {
            model.addAttribute("passwordChangeDTO", new PasswordChangeDTO());
            model.addAttribute("requirePasswordChange", true);
        } else {
            model.addAttribute("requirePasswordChange", false);

            List<BloodInventory> bloodInventory = medicalStaffService.getAllBloodInventory();
            List<BloodRequest> bloodRequests = medicalStaffService.getAllBloodRequests();
            List<BloodRequest> pendingRequests = medicalStaffService.getPendingBloodRequests();
            List<BloodRequest> approvedRequests = medicalStaffService.getApprovedBloodRequests();
            long pendingCount = pendingRequests.size();

            Map<String, Integer> bloodTypeTotals = medicalStaffService.getBloodTypeTotals();
            Map<String, Object> enhancedBloodTypeTotals = medicalStaffService.getEnhancedBloodTypeTotals();
            long criticalStockCount = medicalStaffService.getCriticalStockCount();

            List<Notification> notifications = medicalStaffService.getNotificationsForMedicalStaff(user.getId());

            model.addAttribute("bloodInventory", bloodInventory);
            model.addAttribute("bloodRequests", bloodRequests);
            model.addAttribute("pendingRequests", pendingRequests);
            model.addAttribute("approvedRequests", approvedRequests);
            model.addAttribute("pendingCount", pendingCount);
            model.addAttribute("bloodTypeTotals", bloodTypeTotals);
            model.addAttribute("enhancedBloodTypeTotals", enhancedBloodTypeTotals);
            model.addAttribute("criticalStockCount", criticalStockCount);
            model.addAttribute("notifications", notifications);
        }

        return "medical-staff-dashboard";
    }

    // ===== DONOR NOTIFICATION METHODS =====

    @PostMapping("/notify-donors")
    public String notifyDonorsForBlood(@RequestParam String bloodType,
                                       @RequestParam Integer quantity,
                                       @RequestParam String reason,
                                       HttpSession session,
                                       RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.notifyDonorsForBloodRequest(bloodType, quantity, reason, user);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Urgent blood request sent to all " + bloodType + " donors! They will be notified on their dashboards.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Failed to send donor notifications: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    // ===== NEW FIFO METHODS =====

    @PostMapping("/use-blood")
    public String useBlood(@RequestParam String bloodType,
                           @RequestParam Integer quantity,
                           @RequestParam String reason,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            boolean success = medicalStaffService.useBlood(bloodType, quantity, reason, user);
            if (success) {
                redirectAttributes.addFlashAttribute("successMessage",
                        "Successfully used " + quantity + " units of " + bloodType + " blood using FIFO system. " +
                                "Blood closest to expiration was used first.");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to process blood usage");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error using blood: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/fulfill-request/{requestId}")
    public String fulfillRequest(@PathVariable Long requestId,
                                 @RequestParam(required = false) String notes,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            BloodRequest request = medicalStaffService.fulfillBloodRequest(requestId, user, notes);
            if (request != null) {
                redirectAttributes.addFlashAttribute("successMessage",
                        "Blood request #" + requestId + " fulfilled successfully using FIFO inventory management!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to fulfill blood request");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Error fulfilling request: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @GetMapping("/fifo-details/{bloodType}")
    @ResponseBody
    public ResponseEntity<List<Map<String, Object>>> getFifoDetails(@PathVariable String bloodType) {
        List<Map<String, Object>> fifoDetails = medicalStaffService.getBloodAvailabilityWithFIFO(bloodType);
        return ResponseEntity.ok(fifoDetails);
    }

    @GetMapping("/enhanced-totals")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getEnhancedTotals() {
        Map<String, Object> enhancedTotals = medicalStaffService.getEnhancedBloodTypeTotals();
        return ResponseEntity.ok(enhancedTotals);
    }

    // ===== EXISTING METHODS =====

    @PostMapping("/update-inventory/{inventoryId}")
    public String updateInventory(@PathVariable Long inventoryId,
                                  @RequestParam Integer quantity,
                                  @RequestParam Integer threshold,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            BloodInventory inventory = medicalStaffService.updateBloodInventory(inventoryId, quantity, threshold);
            if (inventory != null) {
                redirectAttributes.addFlashAttribute("successMessage", "Blood inventory updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to update inventory: Inventory not found");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to update inventory: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/add-inventory")
    public String addInventory(@ModelAttribute BloodInventoryDTO bloodInventoryDTO,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            BloodInventory inventory = medicalStaffService.addBloodInventory(bloodInventoryDTO);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Added " + bloodInventoryDTO.getQuantity() + " units of " +
                            bloodInventoryDTO.getBloodType() + " to inventory (Batch: " +
                            inventory.getBatchNumber() + ")");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to add to inventory: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/remove-expired/{batchNumber}")
    public String removeExpiredBlood(@PathVariable String batchNumber,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.removeExpiredBlood(batchNumber);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Expired blood (Batch: " + batchNumber + ") has been removed from inventory");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to remove expired blood: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/delete-inventory/{inventoryId}")
    public String deleteInventory(@PathVariable Long inventoryId,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.deleteInventory(inventoryId);
            redirectAttributes.addFlashAttribute("successMessage", "Blood inventory has been deleted successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to delete inventory: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/delete-expired/{inventoryId}")
    public String deleteExpiredBlood(@PathVariable Long inventoryId,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.deleteExpiredBlood(inventoryId);
            redirectAttributes.addFlashAttribute("successMessage", "Expired blood has been deleted successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to delete expired blood: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/clear-expired-status/{inventoryId}")
    public String clearExpiredStatus(@PathVariable Long inventoryId,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.clearExpiredStatus(inventoryId);
            redirectAttributes.addFlashAttribute("successMessage", "Expired status cleared");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to clear expired status: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/approve-request/{requestId}")
    public String approveRequest(@PathVariable Long requestId,
                                 @RequestParam(required = false) String notes,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            BloodRequest request = medicalStaffService.approveBloodRequest(requestId, user, notes);
            if (request != null) {
                redirectAttributes.addFlashAttribute("successMessage", "Blood request #" + requestId + " approved successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to approve blood request");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error approving request: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/reject-request/{requestId}")
    public String rejectRequest(@PathVariable Long requestId,
                                @RequestParam(required = false) String notes,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            BloodRequest request = medicalStaffService.rejectBloodRequest(requestId, user, notes);
            if (request != null) {
                redirectAttributes.addFlashAttribute("successMessage", "Blood request #" + requestId + " rejected");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to reject blood request");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error rejecting request: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/change-password")
    public String changePassword(@ModelAttribute PasswordChangeDTO passwordChangeDTO,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            boolean success = userService.changePassword(user.getId(), passwordChangeDTO);
            if (success) {
                User updatedUser = userService.getUserById(user.getId());
                session.setAttribute("user", updatedUser);
                redirectAttributes.addFlashAttribute("successMessage", "Password changed successfully!");
                return "redirect:/medical-staff/dashboard";
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to change password. Please check your current password.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error changing password: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @GetMapping("/request-details/{requestId}")
    public String requestDetails(@PathVariable Long requestId, Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        BloodRequest bloodRequest = medicalStaffService.getBloodRequestById(requestId);
        if (bloodRequest == null) {
            return "redirect:/medical-staff/dashboard?error=request_not_found";
        }

        model.addAttribute("bloodRequest", bloodRequest);
        model.addAttribute("user", user);

        return "medical-request-details";
    }

    @GetMapping("/request-history")
    public String requestHistory(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        List<BloodRequest> processedRequests = medicalStaffService.getBloodRequestsByMedicalStaff(user.getId());

        long totalCount = processedRequests != null ? processedRequests.size() : 0;
        long approvedCount = 0;
        long rejectedCount = 0;
        long fulfilledCount = 0;
        long cancelledCount = 0;

        if (processedRequests != null) {
            for (BloodRequest request : processedRequests) {
                switch (request.getStatus()) {
                    case "APPROVED":
                        approvedCount++;
                        break;
                    case "REJECTED":
                        rejectedCount++;
                        break;
                    case "FULFILLED":
                        fulfilledCount++;
                        break;
                    case "CANCELLED":
                        cancelledCount++;
                        break;
                }
            }
        }

        model.addAttribute("bloodRequests", processedRequests);
        model.addAttribute("user", user);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("approvedCount", approvedCount);
        model.addAttribute("rejectedCount", rejectedCount);
        model.addAttribute("fulfilledCount", fulfilledCount);
        model.addAttribute("cancelledCount", cancelledCount);

        return "medical-request-history";
    }

    @GetMapping("/check-expired")
    @ResponseBody
    public Map<String, Object> checkExpiredBlood() {
        long expiredCount = medicalStaffService.getExpiredBloodCount();
        return Map.of("expiredCount", expiredCount);
    }





    // ===== NOTIFICATION DELETION ENDPOINTS =====

    @PostMapping("/delete-notification/{notificationId}")
    public String deleteNotification(@PathVariable Long notificationId,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.deleteNotification(notificationId);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Notification deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Failed to delete notification: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @PostMapping("/delete-all-notifications/{bloodType}")
    public String deleteAllNotificationsByBloodType(@PathVariable String bloodType,
                                                    HttpSession session,
                                                    RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"MEDICAL_STAFF".equals(user.getUser_type())) {
            return "redirect:/login";
        }

        try {
            medicalStaffService.deleteAllNotificationsByBloodType(bloodType);
            redirectAttributes.addFlashAttribute("successMessage",
                    "All notifications for blood type " + bloodType + " have been deleted!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Failed to delete notifications: " + e.getMessage());
        }

        return "redirect:/medical-staff/dashboard";
    }

    @GetMapping("/active-donor-notifications")
    @ResponseBody
    public List<Notification> getActiveDonorNotifications() {
        return medicalStaffService.getActiveDonorNotifications();
    }
}